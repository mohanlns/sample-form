from django import forms
from user.models import ModelForms
from django.forms import CharField, Form, PasswordInput

class NewUserForm(forms.ModelForm):
    class Meta():
        model = ModelForms
        password = forms.CharField(max_length=32, widget=forms.PasswordInput) 
        fields = ('name', 'email', 'password', 'instrument_purchase', 'house_no', 'address_line1', 'address_line2', 'telephone', 'zip_code', 'state', 'country')
