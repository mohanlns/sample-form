from django.contrib import admin
from user.models import ModelForms

# Register your models here.

admin.site.register(ModelForms)
